import React from 'react'
import { Link } from 'react-router-dom'
import { useNavigate } from 'react-router-dom'

function Add() {

  const navigate=useNavigate()

  

  return (
    <div> <nav>
      <ul>
        {/* <li> */}
          navigate('/adddoctor')
        {/* </li> */}
        <li><Link>Add Staff</Link></li>
        <li>
        <Link>Add painet</Link></li>
      </ul>
</nav></div>
  )
}

export default Add