import React from 'react'

function Add_paient() {
  return (
    <div>Add_paient</div>
  )
}

export default Add_paient