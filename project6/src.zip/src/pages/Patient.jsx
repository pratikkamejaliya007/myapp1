import React from 'react'

function Patient() {
  return (
    <div>Patient</div>
  )
}

export default Patient