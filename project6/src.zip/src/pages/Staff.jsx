import React from 'react'

function Staff() {
  return (
    <div>Staff</div>
  )
}

export default Staff