import React from 'react'

function Doctor() {
  return (
    <div>Doctor</div>
  )
}

export default Doctor