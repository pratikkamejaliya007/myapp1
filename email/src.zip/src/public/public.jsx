import React from 'react'
import Header from './Header'

function Public() {
  return (
	  <>
		  <Header/>
	</>
  )
}

export default Public