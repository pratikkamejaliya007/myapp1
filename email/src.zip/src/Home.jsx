import React , {useState , useEffect} from 'react'
import {  signOut } from "firebase/auth";
import { auth } from './config';
import { useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux';
import { setpublic } from './redux-toolkit/privetrouter';
import axios from 'axios';

function Home() {

  const dispatch=useDispatch()
  
    const navigate=useNavigate()

    function handlelogout(){

      signOut(auth).then(() => {
        console.log('Sign-out successful.')
        dispatch(setpublic())
        navigate('/login')
      }).catch((error) => {
        console.log("error")
      });

    }

  const [data, setData] = useState([])

  // console.log(data)
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('https://jsonplaceholder.typicode.com/photos');
        setData(response.data); // Update state with fetched data
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []); // Empty dependency array to run effect only once


  return (
    <div>Home


      <button onClick={handlelogout} className='absolute right-0 top-0'>LOG OUT</button>

    </div>
  )
}

export default Home